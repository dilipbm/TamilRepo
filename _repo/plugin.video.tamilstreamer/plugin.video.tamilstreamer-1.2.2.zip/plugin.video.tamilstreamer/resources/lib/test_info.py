import requests
from bs4 import BeautifulSoup

search_name = 'Mersal'
base_url = 'https://timesofindia.indiatimes.com/'
search_url = 'https://timesofindia.indiatimes.com/moviesearch.cms'

payload = {'q' : search_name}

r = requests.get(search_url, params=payload)

soup = BeautifulSoup(r.content, 'html.parser')


results = [{'movie':result.text,
            'url': base_url + str(result['href'])
            } for result in soup.find_all('a')]

print (results)

#for result in soup.find_all('a'):
#    print (result.text)
#    print (result['href'])


r = requests.get(results[0]['url'])

soup = BeautifulSoup(r.content, 'html.parser')

flmcasting = soup.find_all('div', class_='flmcasting')[0]

title = flmcasting.find('h1').text.replace('Movie Review', '').rstrip()
cast = flmcasting.find('span', class_='casting').text


class Movie(object):
    def __init__(self):
        pass