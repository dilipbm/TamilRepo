import requests
from bs4 import BeautifulSoup
import re




#fin helper


url = 'http://fastplay.to/embed-vmbkhvs0n6vr.html'
r = requests.get(url)
soup = BeautifulSoup(r.content, 'html.parser')


pattern = re.compile("eval(.*?)")
f = soup.find_all(text=pattern)
jw_setup = jsbeautify(str(f[0]).rstrip())
sources = get_sources_jwpl(jw_setup)
