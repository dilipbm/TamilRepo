from bs4 import BeautifulSoup
import requests
import re

url = 'http://videohost2.com/playd.php?id=cj8xavpa64mvw0vsdrr5m2s6c'

html = requests.get(url)
soup = BeautifulSoup(html.content, 'html.parser')
scripts = soup.find_all('script', type="text/javascript")

regex = re.compile('=\[(.*?)];')
scripts_bytecode = re.findall(regex, str(scripts))

for script_bytecode in scripts_bytecode:
    for s in script_bytecode.split(','):
        t = s.decode('string_escape').decode('string_escape')
        #print (t)
        if 'tactile' in t:
            stream_url_path = str(t).replace('"','')

        if '.' in t:
            ext = str(t).replace('"','')



if (stream_url_path and ext):
    stream_url = stream_url_path + str(url.split('=')[-1]) + ext
else:
    print ('Imposible to make stream_url for videohost2')


print (stream_url)