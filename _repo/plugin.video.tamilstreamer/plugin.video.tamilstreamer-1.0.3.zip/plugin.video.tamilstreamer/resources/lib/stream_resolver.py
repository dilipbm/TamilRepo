import re
import helper as helper
from xbmcswift2 import xbmc


addon_id = 'plugin.video.tamilstreamer'
icon_720 = xbmc.translatePath('special://home/addons/{0}/resources/images/icon_720.png'.format(addon_id))
icon_360 = xbmc.translatePath('special://home/addons/{0}/resources/images/icon_360.png'.format(addon_id))
icon_240 = xbmc.translatePath('special://home/addons/{0}/resources/images/icon_240.png'.format(addon_id))

# To load Vidmad Video stream url
def load_vidmad_video(url):
    soup = helper.get_soup_from_url(url)
    script = soup.find_all('script', type="text/javascript")
    # regex = re.compile('file:"(.*?),')
    # regex = re.compile('sources:(.*?)image')
    regex = re.compile('file:(.*?)}')
    videofiles = re.findall(regex, str(script))
    items = []
    for video in videofiles:
        url = None
        quality = ''

        try:
            url = video.split('"')[1]
            quality = video.split('"')[3]
            if quality == '720p':
                quality_icon = icon_720

            elif quality == '360p':
                quality_icon = icon_360

            elif quality == '240p':
                quality_icon = icon_240

            else:
                quality = ''
                quality_icon = ''
        except:
            pass

        d = {'url': url, 'quality': quality, 'quality_icon': quality_icon}
        items.append(d)

    return items


# To load Fastplay Video stream url
def load_fastplay_video(url):
    soup = helper.get_soup_from_url(url)
    script = soup.find_all('script', type="text/javascript")
    # regex = re.compile('file:"(.*?),')
    regex = re.compile('file:(.*?)}')
    videofiles = re.findall(regex, str(script))
    items = []
    for video in videofiles:
        url = None
        quality = ''

        try:
            url = video.split('"')[1]
            quality = video.split('"')[3]
            if quality == '720p':
                quality_icon = icon_720

            elif quality == '360p':
                quality_icon = icon_360

            elif quality == '240p':
                quality_icon = icon_240

            else:
                quality = ''
                quality_icon = ''

        except:
            pass

        d = {'url': url, 'quality': quality, 'quality_icon': quality_icon}
        items.append(d)
    return items
